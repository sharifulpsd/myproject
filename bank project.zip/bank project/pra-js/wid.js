 document.getElementById('btn-wid').addEventListener('click', function(){
    

    const WidthrawField = document.getElementById('widthraw-field');
    const NewwidthrawAmountString = WidthrawField.value;
    const newWidthrawAmount = parseFloat(NewwidthrawAmountString);
 

    const totalWidthrawElement = document.getElementById('total-widthraw');
    const totalWidthrawAmountString = totalWidthrawElement.innerText;
    const totalwidthrawamount = parseFloat(totalWidthrawAmountString);
   

    const currentWidthrawTotal =  totalwidthrawamount + newWidthrawAmount;
    totalWidthrawElement.innerText = currentWidthrawTotal;

    const BalanceTotalElement = document.getElementById('total-balance');
    const previousbalanceAmount = BalanceTotalElement.innerText;
    const previousbalance = parseFloat(previousbalanceAmount);

    const newTotalBalance = previousbalance - newWidthrawAmount;
    BalanceTotalElement.innerText = newTotalBalance;


    WidthrawField.value = '';

 })