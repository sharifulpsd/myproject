 document.getElementById('btn-deposit').addEventListener('click', function(){
     
    const depositField = document.getElementById('deposit-field');
    const NewdepositAmountString = depositField.value;
     const newdepositAmount = parseFloat(NewdepositAmountString);

     const depositTotalElement = document.getElementById('total-deposit');
     const previousDepositTotalString = depositTotalElement.innerText;
     const previousTotalAmount = parseFloat(previousDepositTotalString);
    
     const currentTotalBalance = previousTotalAmount + newdepositAmount;
     depositTotalElement.innerText = currentTotalBalance;

     const currentTotalElement = document.getElementById('total-balance');
     const currentAmountString = currentTotalElement.innerText;
     const currentAmount = parseFloat(currentAmountString);

     const currentTotalAmount = previousTotalAmount +  newdepositAmount;
     currentTotalElement.innerText = currentTotalAmount;


     depositField.value = '';
 })