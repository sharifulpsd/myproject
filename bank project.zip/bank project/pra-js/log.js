 
 document.getElementById('btn-submit').addEventListener('click', function(){
     
    const emailField = document.getElementById('user-email');
    const email = emailField.value;
    
    const PasswordField = document.getElementById('user-password');
    const passward = PasswordField.value;
    console.log(email ,passward);
    
    if(email === 'saimun@gmail.com' && passward === 'saimun'){
        // console.log('valid passdwod');
        window.location.href = 'note.html';
    }
    else{
        console.log('invalid password');
    }

 })