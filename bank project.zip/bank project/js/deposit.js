// step 1 add event listener to the deoposit btn or event handler

document.getElementById('btn-deposit').addEventListener('click', function(){
    // console.log('hey buidy');
    // get the deposit amount form the input field
    const depositField = document.getElementById('deposit-field');
    const NewdeopositAmountString = depositField.value;
    const newDepositAmount = parseFloat(NewdeopositAmountString);
    // console.log(deopositAmount);

    // step number 3 get the deposit total amount
    const depositTotalElement = document.getElementById('total-deposit');
    const previousDepositTotalstring = depositTotalElement.innerText;
    const previousDepositTotal = parseFloat(previousDepositTotalstring);

    //step 4  add number set total deposit
    const currentDepositTotal = previousDepositTotal + newDepositAmount;
    depositTotalElement.innerText = currentDepositTotal;
    // step 5 total balance update
    const currentBalanceElement = document.getElementById('total-balance');
    const previousBalanceString = currentBalanceElement.innerText;
    const previousBalance = parseFloat(previousBalanceString);

    // step 6 
    const currentTotalBalance = previousDepositTotal + newDepositAmount;
    currentBalanceElement.innerText = currentTotalBalance;
    



    // clear the deposit field
    depositField.value = '';
})