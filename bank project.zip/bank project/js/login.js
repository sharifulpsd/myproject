// console.log('saimun');
// step no 1 add event handler  with the submit btn.
 document.getElementById('btn-submit').addEventListener('click', function(){
    // console.log('hello btn');
    // step 2 get the email address inside the email input field
    // always remember to use  .value to get text form an input field.
    const emailField = document.getElementById('user-email');
    const email = emailField.value;
    // step 3 password field
    const passwordField = document.getElementById('user-password');
    const password = passwordField.value;
  
    // step 4 verify email and passward

    if(email === 'saimun@gmail.com' && password === 'secret'){
        window.location.href='bank.html';
    }
    else{
        alert('invalid password')
    }
})