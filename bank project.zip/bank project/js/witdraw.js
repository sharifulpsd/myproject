// step1

document.getElementById('btn-withdraw').addEventListener('click', function(){


// step2
const withdrawField = document.getElementById('withdraw-field');
const newwithdrawAmountString = withdrawField.value;
const newWithdrawAmount = parseFloat(newwithdrawAmountString);
console.log(newWithdrawAmount);
// step 7
withdrawField.value = '';
if(isNaN(newWithdrawAmount)){
    alert('please Provide a valid Number');
    return;
}
// console.log(newWithdrawAmount);
// step 3
const widthrawTotalElement = document.getElementById('total-withdraw');
const previousWidthrawTotalString = widthrawTotalElement.innerText;
const previousWidthrawTotal = parseFloat(previousWidthrawTotalString);
// console.log(previousWidthrawTotal);
// step5
const BalanceTotalElement = document.getElementById('total-balance');
const previousBalanceTotalString = BalanceTotalElement.innerText;
const previousBalanceTotal = parseFloat(previousBalanceTotalString);


if( newWithdrawAmount  > previousBalanceTotal ){
    alert('Account Not Found');
    return;
}

// step 4
const currentwidthrawTotal = previousWidthrawTotal + newWithdrawAmount;
widthrawTotalElement.innerText = currentwidthrawTotal;
// console.log(totalCurrentAmount);
// step6
 const newTotalBalance = previousBalanceTotal - newWithdrawAmount;
 BalanceTotalElement.innerText = newTotalBalance;
 

})