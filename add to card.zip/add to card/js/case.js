// function er vitor bosabo
function UpdateCaseNumber(isIncrease){
    const CaseNumberField = document.getElementById('case-number-field');
    const CaseNumberString = CaseNumberField.value;
    const PreviousCaseamount = parseInt(CaseNumberString);
    
    let  NewCaseNumber;
    if(isIncrease === true){
        NewCaseNumber = PreviousCaseamount + 1;
    }
    else{
        NewCaseNumber = PreviousCaseamount - 1;
    }
     CaseNumberField.value =  NewCaseNumber ; 

     return NewCaseNumber;
}

function UpdateCaseTotalPrice(NewCaseNumber){
    const CaseTotalPrice = NewCaseNumber * 70;
    const TotalCaseElement = document.getElementById('total-case');
    TotalCaseElement.innerText = CaseTotalPrice;
}


// plus btn
document.getElementById('btn-case-plus').addEventListener('click', function(){
   const NewCaseNumber = UpdateCaseNumber(true);
//    price multiple
   UpdateCaseTotalPrice(NewCaseNumber);
   currentSubtotal();

  

})
//   minus btn
document.getElementById('btn-case-minus').addEventListener('click', function(){
    const NewCaseNumber  = UpdateCaseNumber(false);  

    UpdateCaseTotalPrice(NewCaseNumber);
    currentSubtotal();

    
    
     
})