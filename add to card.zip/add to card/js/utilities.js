function getTextelmentValueById(elementId){
    const PhoneTotalElement = document.getElementById(elementId);
    const currentPhoneTotalString = PhoneTotalElement.innerText;
    const currentPhoneTotal = parseInt(currentPhoneTotalString);
    return currentPhoneTotal;
}
    function setTextElementValueById(elementId, value){
    const SubTotalElement = document.getElementById(elementId);
    SubTotalElement.innerText = value;
}

function currentSubtotal(){
    const currentPhoneTotal =  getTextelmentValueById('phone-total');
   const currentCaseTotal =  getTextelmentValueById('total-case');

   const currentSubTotal = currentPhoneTotal + currentCaseTotal;
   setTextElementValueById('sub-total', currentSubTotal);
  

//    calculate tax
const taxAmount = currentSubTotal * 0.1;
setTextElementValueById('tax-amount', taxAmount);

const finalAmount = currentSubTotal + taxAmount;
setTextElementValueById('final-total', finalAmount );
}
