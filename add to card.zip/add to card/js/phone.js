 
function UpdatePhoneNumber(isIncrease){
    const phoneNumberField = document.getElementById('phone-number-field');
    const phoneNumberString = phoneNumberField.value ;
    const previousPhoneNumber = parseInt(phoneNumberString);
   
    let NewPhoneNumbner;
    if(isIncrease === true){
        NewPhoneNumbner = previousPhoneNumber + 1;
    }
    else{
        NewPhoneNumbner = previousPhoneNumber - 1;
    }

    phoneNumberField.value = NewPhoneNumbner;
    return NewPhoneNumbner;
}
function UpdatephoneTotalprice( NewPhoneNumbner){
    const PhoneTotalPrice = NewPhoneNumbner * 2078;
    const phonetotalElement = document.getElementById('phone-total');
    phonetotalElement.innerText =  PhoneTotalPrice;
  
}

function getTextelmentValueById(elementId){
    const PhoneTotalElement = document.getElementById(elementId);
    const currentPhoneTotalString = PhoneTotalElement.innerText;
    const currentPhoneTotal = parseInt(currentPhoneTotalString);
    return currentPhoneTotal;
}
function currentSubtotal(){
    const currentPhoneTotal =  getTextelmentValueById('phone-total');
   const currentCaseTotal =  getTextelmentValueById('total-case');

   const currentSubTotal = currentPhoneTotal + currentCaseTotal;
   const SubTotalElement = document.getElementById('sub-total');
   SubTotalElement.innerText = currentSubTotal;
}
//  plus btn
document.getElementById('btn-phone-plus').addEventListener('click', function(){
  const NewPhoneNumbner = UpdatePhoneNumber(true);
  UpdatephoneTotalprice(NewPhoneNumbner);
  currentSubtotal();

   
  
})

document.getElementById('btn-phone-minus').addEventListener('click', function(){
    const NewPhoneNumbner =  UpdatePhoneNumber(false);
    UpdatephoneTotalprice(NewPhoneNumbner);
    currentSubtotal();
})